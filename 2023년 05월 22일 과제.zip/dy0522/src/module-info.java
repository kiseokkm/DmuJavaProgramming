/**
 * 
 */
/**
 * @author 김기석
 *
 */
module dy0522 {
	requires java.desktop;
}
package dy0329;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class AddrMain {
	static Scanner sc = new Scanner(System.in);
	static ArrayList<Addr> addlist = new ArrayList<>();
	public static void main(String[] args) {
		while(true) {
			System.out.println("-------------------- ");
			System.out.println("1. 주소록 입력  ");
			System.out.println("2. 주소록 검색  ");
			System.out.println("3. 주소록 조회  ");
			System.out.println("4. 주소록 수정   ");
			System.out.println("5. 주소록 삭제   ");
			System.out.println("0. 종료   ");
			System.out.println("------------------ ");
			System.out.println("메뉴를 입력하세요:  ");
			Scanner sc = new Scanner(System.in);
			int num = sc.nextInt();
			if(num ==1) {
				addrInput();				
			}
			else if(num ==2) {
				
			}
			else if(num ==3) {
				
			}
			else if(num ==4) {
				
			}
			else if(num ==5) {
				
			}
			else if(num ==0) {
				System.out.println("종료합니다.");
				
			}
			
		}

	}

	private static void addrInput() {
			System.out.println("이름을 입력하세요.:");
			String name = sc.next();
			System.out.println("전화번호를 입력하세요.:");
			String tel = sc.next();
			System.out.println("회사이름을 입력하세요.:");
			String com = sc.next();
			LocalDateTime dateTime = LocalDateTime.now();
			Addr add1 = new Addr(name,tel,com,dateTime);
			addlist.add(add1);
			System.out.println(add1);
		
	}

}
